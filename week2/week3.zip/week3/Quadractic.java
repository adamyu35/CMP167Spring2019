/*
 * file : Quadractic.java
 * author: Adam
 * created 2/14/19
 * desc : This program implements quadratic formula
 */
import java.util.Scanner;
public class Quadractic {
	public static void main (String [] args) {
		System.out.println("\t\tWelcome to Quadratic 3000");
		System.out.println("This program implements quadractic formula");
		

	
	Scanner input = new Scanner (System.in);
	
	double root1, root2;
	double a, b, c;
	double discr;
	
	System.out.println("Enter value of a:");
	a = input.nextDouble();
	System.out.println("Enter vale of b");
	b = input.nextDouble();
	System.out.println("Enter value of c");
	c = input.nextDouble();
	
	discr = b*b - 4*a*c;
	root1= (-b + Math.sqrt(discr))/2*a;
	root2= (-b - Math.sqrt(discr))/2*a;
	
	

}
}